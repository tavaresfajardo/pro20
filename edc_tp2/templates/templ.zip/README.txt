
TITLE: 
uBeasa - Fully Responsive Free Responsive HTML5 Template

AUTHOR:
DESIGNED & DEVELOPED by freshDesignweb.com

Website: https://www.freshdesignweb.com
Twitter: https://twitter.com/freshdesignweb
Facebook: https://facebook.com/freshdesignweb


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Themify Icons
https://themify.me/themify-icons

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Owl Carousel
http://www.owlcarousel.owlgraphic.com/

FlexSlider
http://flexslider.woothemes.com/

jQuery countTo
http://www.owlcarousel.owlgraphic.com/

Magnific Popup
http://dimsemenov.com/plugins/magnific-popup/



